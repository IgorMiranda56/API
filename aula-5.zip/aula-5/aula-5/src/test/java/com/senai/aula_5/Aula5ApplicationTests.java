package com.senai.aula_5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
