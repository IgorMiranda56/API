package com.senai.aula.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping
@RestController("/")

public class Welcome {

    @GetMapping
    public String welcome() {
        return "Bem-vindo ao Spring Boot!";
    }

    @GetMapping("/hello")
    public String hello() {
        return "Olá, mundo!";
    }

    @GetMapping("/dev")
    public String dev() {
        return "Desenvolvido por: <b>Igor</b>";
    }

}
