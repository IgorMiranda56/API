package com.senai.aula_6.model;

public enum Sexo {
    MASCULINO,
    FEMININO;


}
