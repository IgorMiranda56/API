package com.senai.aula_7.model;

public enum Sexo {
    MASCULINO,
    FEMININO;
}
