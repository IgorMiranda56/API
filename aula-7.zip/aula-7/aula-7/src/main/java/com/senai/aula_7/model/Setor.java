package com.senai.aula_7.model;

public enum Setor {
    ENGENHARIA,
    SAUDE,
    JURIDICO;
}
