package com.senai.aula_3.service;

import com.senai.aula_3.model.Funcionario;
import com.senai.aula_3.repository.FuncionarioRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FuncionarioService {
    private final FuncionarioRepository funcionarioRepository;

    public FuncionarioService(FuncionarioRepository funcionarioRepository) {
        this.funcionarioRepository = funcionarioRepository;
    }

    public void salvar(Funcionario funcionario) {
        funcionarioRepository.save(funcionario);
    }

    public void deletarPorId(Long id) {
        funcionarioRepository.deleteById(id);
    }

    public Funcionario buscarPorId(Long id) {
        return funcionarioRepository.findById(id).orElseThrow();
    }

    public List<Funcionario> buscarTodos() {
        return funcionarioRepository.findAll();
    }

    public void atualizar(Funcionario funcionario) {
        funcionarioRepository.save(funcionario);
    }

}
